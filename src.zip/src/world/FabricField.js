// src/world/FabricField.js
// Spacetime Fabric Grid (NO SHADERS)
// - Uses Chunk._fade (0..1) to show grid ONLY where land fades out
// - Smooth ramps (no hard pop)
// - Distance fade for “vanishing fabric” look
// - Crisp grid (no “green haze”) via sparse lines + NEAREST sampling

import {
    MeshBuilder,
    StandardMaterial,
    DynamicTexture,
    Texture,
    Color3,
    Engine,
    Vector3,
} from "@babylonjs/core";

import { Chunk } from "./Chunk.js";

export class FabricField {
    /**
     * @param {import('@babylonjs/core').Scene} scene
     * @param {import('./World.js').World} world
     */
    constructor(scene, world) {
        this.scene = scene;
        this.world = world;

        const b = world.bounds;

        // generous padding so fabric extends beyond terrain
        this._pad = 240;

        const worldW = (b.maxWorldX - b.minWorldX) + 1;
        const worldH = (b.maxWorldZ - b.minWorldZ) + 1;

        const planeW = worldW + this._pad * 2;
        const planeH = worldH + this._pad * 2;

        this._planeMinX = b.minWorldX - this._pad;
        this._planeMinZ = b.minWorldZ - this._pad;
        this._planeW = planeW;
        this._planeH = planeH;

        // Put it BELOW all voxels so it can never overlay visible land.
        // Chunk bedrock in your code goes to around -92, so go lower.
        this._y = -140;

        this.mesh = MeshBuilder.CreateGround(
            "fabricField",
            { width: planeW, height: planeH, subdivisions: 1 },
            scene
        );

        this.mesh.position = new Vector3(
            (b.minWorldX + b.maxWorldX) * 0.5,
            this._y,
            (b.minWorldZ + b.maxWorldZ) * 0.5
        );

        this.mesh.isPickable = false;
        this.mesh.alwaysSelectAsActiveMesh = true;
        this.mesh.renderingGroupId = 0;

        // ---- textures ----
        // Grid can be small (tileable). Mask should be higher for smoother fading.
        this._gridSize = 512;
        this._maskSize = 512;

        this._gridDT = new DynamicTexture(
            "fabricGrid",
            { width: this._gridSize, height: this._gridSize },
            scene,
            false
        );
        this._gridDT.hasAlpha = true;
        this._gridDT.wrapU = Texture.WRAP_ADDRESSMODE;
        this._gridDT.wrapV = Texture.WRAP_ADDRESSMODE;

        // IMPORTANT: avoid filtering blur that turns lines into “green haze”
        this._gridDT.updateSamplingMode(Texture.NEAREST_SAMPLINGMODE);

        this._maskDT = new DynamicTexture(
            "fabricMask",
            { width: this._maskSize, height: this._maskSize },
            scene,
            false
        );
        this._maskDT.hasAlpha = true;
        this._maskDT.wrapU = Texture.CLAMP_ADDRESSMODE;
        this._maskDT.wrapV = Texture.CLAMP_ADDRESSMODE;

        // IMPORTANT: keep mask crisp/consistent (no unexpected soft blobs)
        this._maskDT.updateSamplingMode(Texture.NEAREST_SAMPLINGMODE);

        this._drawGridTexture();
        this._clearMaskToInvisible();

        // ---- material ----
        const mat = new StandardMaterial("fabricFieldMat", scene);
        mat.disableLighting = true;
        mat.diffuseColor = new Color3(0, 0, 0);
        mat.specularColor = new Color3(0, 0, 0);

        mat.emissiveTexture = this._gridDT;
        // green/cyan “fabric”
        mat.emissiveColor = new Color3(0.12, 1.0, 0.35);

        mat.opacityTexture = this._maskDT;
        mat.alpha = 1.0;

        // Keep depth write ON so visible land always occludes it if ever intersected
        mat.alphaMode = Engine.ALPHA_COMBINE;
        mat.backFaceCulling = false;
        mat.disableDepthWrite = false;

        this.mesh.material = mat;
        this.material = mat;

        // World units per cell. Larger = less dense grid (more “real grid”, less haze)
        this._cellWorld = 28;

        this._gridDT.uScale = planeW / this._cellWorld;
        this._gridDT.vScale = planeH / this._cellWorld;

        // animation
        this._t = 0;
        this._gridScrollSpeed = 0.006;

        // rebuild throttling (CPU)
        this._maskTimer = 0;
        this._maskEvery = 0.16;

        // --- fade behavior tuning ---
        // Chunk fade is 1=fully visible.
        // We want **ZERO** grid in clearly-visible land, even through voxel gaps.
        // So we wait until fade meaningfully drops before the grid begins to appear.
        // (The previous 0.985 was too aggressive for your falloff and made the grid show everywhere.)
        this._fadeStart = 0.92;  // above this = no grid
        this._fadeFull  = 0.58;  // at/under this = grid is strong (but still capped)

        // also fade grid out again in deep fog (so it doesn't become a flat carpet)
        this._deepStart = 0.26;  // when fade gets very low
        this._deepEnd   = 0.06;  // fade to almost nothing

        // distance fade (camera-based)
        this._distNear = 220;
        this._distFar = 1250;

        // alpha caps (prevents sheet)
        this._alphaScale = 0.62;
        this._alphaCap = 0.55;

        // initial build
        this._rebuildMaskFromChunkFade();
    }

    _clamp01(x) {
        return Math.max(0, Math.min(1, x));
    }

    _smooth01(t) {
        const x = this._clamp01(t);
        return x * x * (3 - 2 * x);
    }

    _smoothstep(edge0, edge1, x) {
        const t = this._clamp01((x - edge0) / Math.max(1e-6, (edge1 - edge0)));
        return this._smooth01(t);
    }

    _getChunkFade(cx, cz) {
        const ch = this.world.chunks?.get(`${cx},${cz}`);
        if (!ch) return 0;
        const f = typeof ch._fade === "number" ? ch._fade : 0;
        return this._clamp01(f);
    }

    _sampleFadeBilinear(worldX, worldZ) {
        const size = Chunk.SIZE;

        const fx = worldX / size;
        const fz = worldZ / size;

        const cx0 = Math.floor(fx);
        const cz0 = Math.floor(fz);
        const cx1 = cx0 + 1;
        const cz1 = cz0 + 1;

        const tx = fx - cx0;
        const tz = fz - cz0;

        const f00 = this._getChunkFade(cx0, cz0);
        const f10 = this._getChunkFade(cx1, cz0);
        const f01 = this._getChunkFade(cx0, cz1);
        const f11 = this._getChunkFade(cx1, cz1);

        const a = f00 * (1 - tx) + f10 * tx;
        const b = f01 * (1 - tx) + f11 * tx;
        return a * (1 - tz) + b * tz;
    }

    _distanceFade(worldX, worldZ) {
        const cam = this.scene.activeCamera;
        if (!cam) return 1;

        const dx = worldX - cam.position.x;
        const dz = worldZ - cam.position.z;
        const d = Math.sqrt(dx * dx + dz * dz);

        // 1 near, smoothly to 0 far
        const t = this._smoothstep(this._distNear, this._distFar, d);
        return 1 - t;
    }

    _drawGridTexture() {
        const ctx = this._gridDT.getContext();
        const s = this._gridSize;

        // Transparent background (RGB 0). That means only lines emit light.
        ctx.clearRect(0, 0, s, s);

        // We want a SPARSE grid, not a dense mesh that becomes haze.
        // So: big cell spacing in texture space, a little glow per line.
        const minor = 32; // less frequent
        const major = 128;

        // thin line core
        const drawLine = (x0, y0, x1, y1, w, a) => {
            ctx.globalAlpha = a;
            ctx.strokeStyle = "white";
            ctx.lineWidth = w;
            ctx.beginPath();
            ctx.moveTo(x0, y0);
            ctx.lineTo(x1, y1);
            ctx.stroke();
        };

        // Minor lines (very subtle)
        for (let x = 0; x <= s; x += minor) {
            drawLine(x, 0, x, s, 1, 0.18);
            drawLine(x, 0, x, s, 3, 0.04); // soft halo
        }
        for (let y = 0; y <= s; y += minor) {
            drawLine(0, y, s, y, 1, 0.18);
            drawLine(0, y, s, y, 3, 0.04);
        }

        // Major lines (stronger)
        for (let x = 0; x <= s; x += major) {
            drawLine(x, 0, x, s, 2, 0.55);
            drawLine(x, 0, x, s, 6, 0.08);
        }
        for (let y = 0; y <= s; y += major) {
            drawLine(0, y, s, y, 2, 0.55);
            drawLine(0, y, s, y, 6, 0.08);
        }

        // Subtle diagonal “fabric weave”
        for (let i = -s; i < s * 2; i += major) {
            drawLine(i, 0, i - s, s, 1, 0.08);
        }

        ctx.globalAlpha = 1.0;
        this._gridDT.update(false);
    }

    _clearMaskToInvisible() {
        const ctx = this._maskDT.getContext();
        const s = this._maskSize;
        ctx.clearRect(0, 0, s, s);
        this._maskDT.update(false);
    }

    _rebuildMaskFromChunkFade() {
        const ctx = this._maskDT.getContext();
        const s = this._maskSize;

        const img = ctx.createImageData(s, s);
        const data = img.data;

        for (let py = 0; py < s; py++) {
            const v = py / (s - 1);
            const wz = this._planeMinZ + v * this._planeH;

            for (let px = 0; px < s; px++) {
                const u = px / (s - 1);
                const wx = this._planeMinX + u * this._planeW;

                const fade = this._sampleFadeBilinear(wx, wz);

                // fade -> fog strength (0 visible, 1 hidden)
                const fog = 1 - fade;

                // 1) Appear smoothly when fade starts dropping (NO hard cutoff)
                const appear = 1 - this._smoothstep(this._fadeStart, this._fadeFull, fade);

                // 2) Fade down again in deep fog so it’s not a solid carpet
                const deepFade = this._smoothstep(this._deepEnd, this._deepStart, fade);

                // 3) Camera distance fade (the fabric itself “vanishes”)
                const distF = this._distanceFade(wx, wz);

                // Final presence
                let a = appear * deepFade * distF;

                // Slightly bias by fog so boundary is clearer than deep fog
                a *= (0.65 + fog * 0.35);

                a *= this._alphaScale;
                if (a <= 0.001) continue;
                if (a > this._alphaCap) a = this._alphaCap;

                const idx = (py * s + px) * 4;
                data[idx + 0] = 0;
                data[idx + 1] = 0;
                data[idx + 2] = 0;
                data[idx + 3] = (a * 255) | 0;
            }
        }

        ctx.putImageData(img, 0, 0);
        this._maskDT.update(false);
    }

    // Keep API compatibility if something calls it
    setVision(_lights) {}

    update(dt) {
        this._t += Math.max(0, dt);

        // animate the grid slightly
        const scroll = this._t * this._gridScrollSpeed;
        this._gridDT.uOffset = scroll;
        this._gridDT.vOffset = scroll * 0.62;

        this._maskTimer += dt;
        if (this._maskTimer >= this._maskEvery) {
            this._maskTimer = 0;
            this._rebuildMaskFromChunkFade();
        }
    }

    dispose() {
        if (this.mesh) this.mesh.dispose(false, true);
        this.mesh = null;

        if (this._gridDT) this._gridDT.dispose();
        if (this._maskDT) this._maskDT.dispose();

        this._gridDT = null;
        this._maskDT = null;
        this.material = null;
    }
}
