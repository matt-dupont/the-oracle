// src/world/World.js
import { Chunk } from "./Chunk.js";
import { getHeight } from "./terrain.js";

function buildSpiralCoords(minCx, maxCx, minCz, maxCz) {
    const coords = [];
    const inBounds = (cx, cz) => cx >= minCx && cx <= maxCx && cz >= minCz && cz <= maxCz;

    let cx = 0;
    let cz = 0;
    if (!inBounds(cx, cz)) {
        cx = Math.max(minCx, Math.min(maxCx, 0));
        cz = Math.max(minCz, Math.min(maxCz, 0));
    }

    const seen = new Set();
    const push = (x, z) => {
        const k = `${x},${z}`;
        if (!seen.has(k) && inBounds(x, z)) {
            seen.add(k);
            coords.push({ cx: x, cz: z });
        }
    };

    push(cx, cz);

    let step = 1;
    const total = (maxCx - minCx + 1) * (maxCz - minCz + 1);

    while (coords.length < total) {
        for (let i = 0; i < step; i++) { cx += 1; push(cx, cz); }
        for (let i = 0; i < step; i++) { cz += 1; push(cx, cz); }
        step++;

        for (let i = 0; i < step; i++) { cx -= 1; push(cx, cz); }
        for (let i = 0; i < step; i++) { cz -= 1; push(cx, cz); }
        step++;

        if (step > 10000) break;
    }

    return coords;
}

function clamp01(x) {
    return Math.max(0, Math.min(1, x));
}

function smooth01(t) {
    const x = clamp01(t);
    return x * x * (3 - 2 * x);
}

export class World {
    /**
     * @param {import('@babylonjs/core').Scene} scene
     * @param {{ sizeChunks?: number, budgetBoot?: number, budgetSteady?: number }} [opts]
     */
    constructor(scene, opts = {}) {
        this.scene = scene;
        this.chunks = new Map();

        this.totalChunks = 0;
        this.createdChunks = 0;

        const sizeChunks = Math.max(9, Math.floor(opts.sizeChunks ?? 25));
        this.sizeChunks = sizeChunks % 2 === 0 ? sizeChunks + 1 : sizeChunks;

        const half = Math.floor(this.sizeChunks / 2);
        this.minCx = -half;
        this.maxCx = half;
        this.minCz = -half;
        this.maxCz = half;

        this.minWorldX = this.minCx * Chunk.SIZE;
        this.maxWorldX = (this.maxCx + 1) * Chunk.SIZE - 1;
        this.minWorldZ = this.minCz * Chunk.SIZE;
        this.maxWorldZ = (this.maxCz + 1) * Chunk.SIZE - 1;

        this._pendingCreates = buildSpiralCoords(this.minCx, this.maxCx, this.minCz, this.maxCz);
        this.totalChunks = this._pendingCreates.length;

        this._budgetBoot = Math.max(1, Math.floor(opts.budgetBoot ?? 48));
        this._budgetSteady = Math.max(1, Math.floor(opts.budgetSteady ?? 10));
        this._bootstrapSeconds = 1.8;

        this.bounds = {
            minWorldX: this.minWorldX,
            maxWorldX: this.maxWorldX,
            minWorldZ: this.minWorldZ,
            maxWorldZ: this.maxWorldZ,
        };

        this._visHash = "";
    }

    _key(cx, cz) {
        return `${cx},${cz}`;
    }

    update(dt = 0.016) {
        if (this._pendingCreates.length > 0) {
            this._bootstrapSeconds = Math.max(0, this._bootstrapSeconds - dt);
            const budget = this._bootstrapSeconds > 0 ? this._budgetBoot : this._budgetSteady;

            for (let i = 0; i < budget && this._pendingCreates.length > 0; i++) {
                const next = this._pendingCreates.shift();
                if (!next) break;

                const key = this._key(next.cx, next.cz);
                if (this.chunks.has(key)) continue;

                const ch = new Chunk(next.cx, next.cz, this.scene);
                this.chunks.set(key, ch);
                this.createdChunks++;
            }
        }

        // IMPORTANT: allow chunks to ease their fade (if Chunk.js implements smoothing)
        for (const ch of this.chunks.values()) {
            if (typeof ch.update === "function") ch.update(dt);
        }
    }

    get progress() {
        if (this.totalChunks <= 0) return 1;
        return Math.max(0, Math.min(1, this.createdChunks / this.totalChunks));
    }

    get isReady() {
        return this._pendingCreates.length === 0;
    }

    clampWorldXZ(x, z, margin = 8) {
        const minX = this.minWorldX + margin;
        const maxX = this.maxWorldX - margin;
        const minZ = this.minWorldZ + margin;
        const maxZ = this.maxWorldZ - margin;
        return {
            x: Math.max(minX, Math.min(maxX, x)),
            z: Math.max(minZ, Math.min(maxZ, z)),
        };
    }

    getGroundY(worldX, worldZ) {
        return getHeight(worldX, worldZ);
    }

    /**
     * Smooth, non-abrupt fog-of-war fade.
     * - Keeps your existing “vanishing mesh” vibe.
     * - Avoids harsh rings / sudden transparency.
     * - Uses a wider outer band so the fade is visibly gradual.
     *
     * @param {{x:number,z:number,r:number}[]} lights
     * @param {{innerMul?:number, outerMul?:number}} [options]
     */
    applyVisionLights(lights, options = {}) {
        // RESTORE sane defaults (these were the #1 cause of "engine got destroyed")
        const innerMul = typeof options.innerMul === "number" ? options.innerMul : 0.80;
        const outerMul = typeof options.outerMul === "number" ? options.outerMul : 1.60;

        if (!lights || lights.length === 0) {
            for (const ch of this.chunks.values()) ch.setFade(0);
            return;
        }

        // Hash to avoid pointless recompute
        let h = `${innerMul.toFixed(2)}|${outerMul.toFixed(2)}|`;
        for (let i = 0; i < lights.length; i++) {
            const L = lights[i];
            h += `${(L.x | 0)},${(L.z | 0)},${(L.r | 0)};`;
        }
        if (h === this._visHash) return;
        this._visHash = h;

        // Use chunk center for smooth radial falloff, BUT with wide outer band (prevents pop)
        const half = Chunk.SIZE * 0.5;

        for (const ch of this.chunks.values()) {
            const cx = ch.cx * Chunk.SIZE + half;
            const cz = ch.cz * Chunk.SIZE + half;

            let best = 0;

            for (let i = 0; i < lights.length; i++) {
                const L = lights[i];

                const inner = Math.max(1, L.r * innerMul);
                const outer = Math.max(inner + 1, L.r * outerMul);

                const dx = cx - L.x;
                const dz = cz - L.z;
                const d2 = dx * dx + dz * dz;

                if (d2 <= inner * inner) {
                    best = 1;
                    break;
                }

                if (d2 < outer * outer) {
                    const d = Math.sqrt(d2);
                    const t = (d - inner) / (outer - inner); // 0..1
                    const s = smooth01(t);
                    const fade = 1 - s;
                    if (fade > best) best = fade;
                }
            }

            // Clamp + feed to chunk smoothing
            ch.setFade(clamp01(best));
        }
    }
}
