// src/world/Chunk.js
import {
    MeshBuilder,
    StandardMaterial,
    Color3,
    Matrix,
    Vector3,
    Quaternion,
    Material,
    Engine,
} from "@babylonjs/core";

import { getHeight, getColorForHeight, WATER_LEVEL } from "./terrain.js";

export class Chunk {
    static SIZE = 16;

    /**
     * @param {number} cx
     * @param {number} cz
     * @param {import('@babylonjs/core').Scene} scene
     * @param {{minWorldX:number,maxWorldX:number,minWorldZ:number,maxWorldZ:number}} bounds
     */
    constructor(cx, cz, scene, bounds) {
        this.cx = cx;
        this.cz = cz;
        this.scene = scene;
        this.bounds = bounds;

        this.surfaceMesh = null;
        this.waterMesh = null;

        this._fade = 1;

        // Corner fade field (f00,f10,f01,f11). Used to generate smooth falloff inside a chunk.
        this._fadeCorners = { f00: 1, f10: 1, f01: 1, f11: 1 };

        // Thin-instance color buffers + per-instance XZ (used for per-instance alpha fade)
        this._surfaceColorBuffer = null;
        this._waterColorBuffer = null;
        this._surfaceBaseAlpha = null;
        this._waterBaseAlpha = null;
        this._surfaceXZ = null;
        this._waterXZ = null;

        this._generate();
    }

    // Legacy API (kept so nothing else breaks if it still calls setFade somewhere)
    setFade(f) {
        const ff = Math.max(0, Math.min(1, f));
        this._fade = ff;

        // IMPORTANT: do not use this for visuals anymore (it causes chunky edges).
        // Keep only as a cheap visibility toggle fallback.
        const shown = ff > 0.02;
        if (this.surfaceMesh) this.surfaceMesh.isVisible = shown;
        if (this.waterMesh) this.waterMesh.isVisible = shown;
        if (this.surfaceMesh) this.surfaceMesh.visibility = 1;
        if (this.waterMesh) this.waterMesh.visibility = 1;
    }

    /**
     * Set fade field by corners (world-space chunk corners). This is the key fix:
     * instead of fading the *entire chunk* uniformly, we fade each voxel instance
     * by bilinear interpolation across the chunk. Result: smooth fog boundary,
     * no "hard square" chunk edges.
     *
     * @param {number} f00 fade at (x0,z0)
     * @param {number} f10 fade at (x1,z0)
     * @param {number} f01 fade at (x0,z1)
     * @param {number} f11 fade at (x1,z1)
     */
    setFadeCorners(f00, f10, f01, f11) {
        const c00 = Math.max(0, Math.min(1, f00));
        const c10 = Math.max(0, Math.min(1, f10));
        const c01 = Math.max(0, Math.min(1, f01));
        const c11 = Math.max(0, Math.min(1, f11));

        // Avoid thrash if corners barely changed
        const prev = this._fadeCorners;
        if (
            Math.abs(prev.f00 - c00) < 0.01 &&
            Math.abs(prev.f10 - c10) < 0.01 &&
            Math.abs(prev.f01 - c01) < 0.01 &&
            Math.abs(prev.f11 - c11) < 0.01
        ) {
            return;
        }

        this._fadeCorners = { f00: c00, f10: c10, f01: c01, f11: c11 };

        // For culling: if basically invisible everywhere, hide the meshes.
        // Keep the threshold *very* low to avoid popping.
        const maxFade = Math.max(c00, c10, c01, c11);
        const shown = maxFade > 0.005;
        if (this.surfaceMesh) this.surfaceMesh.isVisible = shown;
        if (this.waterMesh) this.waterMesh.isVisible = shown;

        // Update per-instance alpha smoothly.
        this._applyFadeToInstances();
    }

    _smooth01(t) {
        const x = Math.max(0, Math.min(1, t));
        return x * x * (3 - 2 * x);
    }

    _bilinearFade01(u, v) {
        const c = this._fadeCorners;
        const u1 = 1 - u;
        const v1 = 1 - v;
        return (
            c.f00 * (u1 * v1) +
            c.f10 * (u * v1) +
            c.f01 * (u1 * v) +
            c.f11 * (u * v)
        );
    }

    _applyFadeToInstances() {
        if (!this.surfaceMesh || !this._surfaceColorBuffer || !this._surfaceBaseAlpha || !this._surfaceXZ) return;

        // Map fade so fully visible land stays solid, and the boundary feels soft.
        // This is the fix for "suddenly transparent".
        const mapFade = (f) => {
            const a0 = 0.18; // start fading
            const a1 = 0.92; // fully visible by here
            const t = (f - a0) / Math.max(1e-6, (a1 - a0));
            return this._smooth01(t);
        };

        const inv = 1 / Chunk.SIZE;

        const col = this._surfaceColorBuffer;
        const baseA = this._surfaceBaseAlpha;
        const xz = this._surfaceXZ;
        const n = baseA.length;

        for (let i = 0; i < n; i++) {
            const lx = xz[i * 2 + 0];
            const lz = xz[i * 2 + 1];
            const u = Math.max(0, Math.min(1, (lx + 0.5) * inv));
            const v = Math.max(0, Math.min(1, (lz + 0.5) * inv));
            const f = this._bilinearFade01(u, v);
            const a = baseA[i] * mapFade(f);
            col[i * 4 + 3] = a;
        }

        // Water uses same fade but slightly reduced so it doesn't glow.
        if (this.waterMesh && this._waterColorBuffer && this._waterBaseAlpha && this._waterXZ) {
            const wcol = this._waterColorBuffer;
            const wbaseA = this._waterBaseAlpha;
            const wxz = this._waterXZ;
            const wn = wbaseA.length;
            for (let i = 0; i < wn; i++) {
                const lx = wxz[i * 2 + 0];
                const lz = wxz[i * 2 + 1];
                const u = Math.max(0, Math.min(1, (lx + 0.5) * inv));
                const v = Math.max(0, Math.min(1, (lz + 0.5) * inv));
                const f = this._bilinearFade01(u, v);
                const a = wbaseA[i] * (mapFade(f) * 0.92);
                wcol[i * 4 + 3] = a;
            }
            this.waterMesh.thinInstanceBufferUpdated("color");
        }

        this.surfaceMesh.thinInstanceBufferUpdated("color");

        // Keep mesh.visibility at 1 so we don't double-apply alpha.
        this.surfaceMesh.visibility = 1;
        if (this.waterMesh) this.waterMesh.visibility = 1;
    }

    update(dt) {
        // no per-frame updates needed
    }

    _generate() {
        const size = Chunk.SIZE;
        const xOffset = this.cx * size;
        const zOffset = this.cz * size;

        const surface = MeshBuilder.CreateBox(
            `surface_${this.cx}_${this.cz}`,
            { size: 1 },
            this.scene
        );
        surface.isVisible = true;
        surface.isPickable = false;

        const water = MeshBuilder.CreateBox(
            `water_${this.cx}_${this.cz}`,
            { size: 1 },
            this.scene
        );
        water.isVisible = true;
        water.isPickable = false;

        // Materials
        const surfMat = new StandardMaterial(`surfMat_${this.cx}_${this.cz}`, this.scene);
        surfMat.disableLighting = false;
        surfMat.useVertexColors = true;
        surfMat.emissiveColor = new Color3(0, 0, 0);
        surfMat.diffuseColor = new Color3(1, 1, 1);
        surfMat.specularColor = new Color3(0, 0, 0);
        // Enable vertex/instance alpha (fog fade).
        surfMat.transparencyMode = Material.MATERIAL_ALPHABLEND;
        surfMat.alphaMode = Engine.ALPHA_COMBINE;
        surface.material = surfMat;

        const waterMat = new StandardMaterial(`waterMat_${this.cx}_${this.cz}`, this.scene);
        waterMat.disableLighting = true;
        waterMat.useVertexColors = true;
        waterMat.alpha = 0.70;
        waterMat.emissiveColor = new Color3(0.00, 0.25, 0.35);
        waterMat.specularColor = new Color3(0, 0, 0);
        water.material = waterMat;

        /** @type {number[]} */
        const surfaceMatrices = [];
        /** @type {number[]} */
        const surfaceColors = [];
        /** @type {number[]} */
        const surfaceXZ = [];
        /** @type {number[]} */
        const waterMatrices = [];
        /** @type {number[]} */
        const waterColors = [];
        /** @type {number[]} */
        const waterXZ = [];

        const m = Matrix.Identity();
        const q = Quaternion.Identity();
        const pos = new Vector3();

        const pushSurface = (lx, y, lz, c, a = 1) => {
            pos.set(xOffset + lx + 0.5, y + 0.5, zOffset + lz + 0.5);
            Matrix.ComposeToRef(new Vector3(1, 1, 1), q, pos, m);

            const cc = c instanceof Color3 ? c : new Color3(c.r, c.g, c.b);
            surfaceMatrices.push(...m.toArray());
            surfaceColors.push(cc.r, cc.g, cc.b, a);
            surfaceXZ.push(lx, lz);
        };

        const pushWater = (lx, y, lz, c, a = 1) => {
            pos.set(xOffset + lx + 0.5, y + 0.5, zOffset + lz + 0.5);
            Matrix.ComposeToRef(new Vector3(1, 1, 1), q, pos, m);

            const cc = c instanceof Color3 ? c : new Color3(c.r, c.g, c.b);
            waterMatrices.push(...m.toArray());
            waterColors.push(cc.r, cc.g, cc.b, a);
            waterXZ.push(lx, lz);
        };

        // Build columns
        for (let lz = 0; lz < size; lz++) {
            for (let lx = 0; lx < size; lx++) {
                const wx = xOffset + lx;
                const wz = zOffset + lz;

                const h = getHeight(wx, wz) | 0;


                // ground stack
                const depth = 6;
                for (let y = Math.max(0, h - depth); y <= h; y++) {
                    const c = getColorForHeight(wx, wz, y);
                    pushSurface(lx, y, lz, c, 1);
                }

                // water surface (one block)
                if (h < WATER_LEVEL) {
                    pushWater(lx, WATER_LEVEL, lz, new Color3(0.03, 0.25, 0.34), 0.85);
                }
            }
        }

        // Thin instances
        surface.thinInstanceSetBuffer("matrix", new Float32Array(surfaceMatrices), 16, true);
        const surfaceColorBuf = new Float32Array(surfaceColors);
        surface.thinInstanceSetBuffer("color", surfaceColorBuf, 4, true);

        water.thinInstanceSetBuffer("matrix", new Float32Array(waterMatrices), 16, true);
        const waterColorBuf = new Float32Array(waterColors);
        water.thinInstanceSetBuffer("color", waterColorBuf, 4, true);

        this.surfaceMesh = surface;
        this.waterMesh = water;

        // Cache buffers + base alpha so we can update alpha without rebuilding geometry.
        this._surfaceColorBuffer = surfaceColorBuf;
        this._waterColorBuffer = waterColorBuf;

        const surfCount = (surfaceColorBuf.length / 4) | 0;
        const watCount = (waterColorBuf.length / 4) | 0;

        this._surfaceBaseAlpha = new Float32Array(surfCount);
        for (let i = 0; i < surfCount; i++) this._surfaceBaseAlpha[i] = surfaceColorBuf[i * 4 + 3];

        this._waterBaseAlpha = new Float32Array(watCount);
        for (let i = 0; i < watCount; i++) this._waterBaseAlpha[i] = waterColorBuf[i * 4 + 3];

        this._surfaceXZ = new Float32Array(surfaceXZ);
        this._waterXZ = new Float32Array(waterXZ);

        // Apply current fade field immediately
        this._applyFadeToInstances();
    }

    dispose() {
        if (this.surfaceMesh) this.surfaceMesh.dispose();
        if (this.waterMesh) this.waterMesh.dispose();
        this.surfaceMesh = null;
        this.waterMesh = null;
    }
}
